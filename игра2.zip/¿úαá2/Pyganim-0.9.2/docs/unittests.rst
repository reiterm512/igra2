.. default-role:: code
==========
Unit Tests
==========

The unit tests under /tests can be run from Python 2 or 3. In that folder are several test image files needed to run the tests (bolt1.png to bolt10.png, etc.)

    > python basicTests.py
