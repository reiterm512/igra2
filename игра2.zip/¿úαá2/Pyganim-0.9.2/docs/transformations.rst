.. default-role:: code
===============
Transformations
===============

TODO

See, flip(), scale(), rotate(), rotozoom(), scale2x(), smoothscale(), convert(), convert_alpha(). When called on the PygAnimation object, they are applied to all the pygame.Surface objects in the animation. They do the same thing as the pygame.Surface methods of the same names.