.. Pyganim documentation master file, created by
   sphinx-quickstart on Sun Aug  3 14:57:25 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Pyganim's documentation!
===================================

Contents:

.. toctree::
   :maxdepth: 2

   install.rst
   basics.rst
   spritesheets.rst
   transformations.rst
   unittests.rst



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

