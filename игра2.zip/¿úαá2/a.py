# -*- coding: cp1251 -*-
import pygame

pygame.display.set_caption("legush'ka")

from Player import Player
from Platforms import Platform

SIZE = (750, 600)

window = pygame.display.set_mode(SIZE)
screen = pygame.Surface(SIZE)

ANIMATION_STAY = pygame.image.load('images/lll.png')
ANIMATION_STAY = pygame.image.load('images/lll2.png')
bg = pygame.image.load('images/fff.jpg')

hero = Player(90, 71)
width = 90
heidht = 71
left = right = up = False

level = [
       "-------------------------",
       "-                       -",
       "-                       -",
       "-                       -",
       "-            --         -",
       "-                       -",
       "--                      -",
       "-                       -",
       "-                   --- -",
       "-                       -",
       "-                       -",
       "-      ---              -",
       "-                       -",
       "-   -----------         -",
       "-                       -",
       "-                -      -",
       "-                   --  -",
       "-                       -",
       "-                       -",
       "-------------------------"
       ]

sprite_group = pygame.sprite.Group()
sprite_group.add(hero)
platfroms = []

x = 0
y = 0

for row in level:
    for col in row:
        if col == '-':
            pl = Platform(x, y)
            sprite_group.add(pl)
            platfroms.append(pl)
        x += 30
    y += 30
    x = 0

run = True

timer = pygame.time.Clock()

while run:
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            run = False

        if e.type == pygame.KEYDOWN:
            if e.key == pygame.K_LEFT:
                left = True
            if e.key == pygame.K_RIGHT:
                right = True
            if e.key == pygame.K_UP:
                up = True

        if e.type == pygame.KEYUP:
            if e.key == pygame.K_LEFT:
                left = False
            if e.key == pygame.K_RIGHT:
                right = False
            if e.key == pygame.K_UP:
                up = False

   
    hero.update(left, right, up, platfroms)
    sprite_group.draw(screen)
    
    
    
    window.blit(screen,(0, 0))
    
    pygame.display.flip()

    screen.blit(bg, (0, 0))
    timer.tick(60)
