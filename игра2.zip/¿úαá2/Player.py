# -*- coding: cp1251 -*-

from pygame.sprite import Sprite, collide_rect
from pygame import Surface, mixer
import pyganim


MOVE_SPEED = 7
JUMP_POWER = 10

GRAVITY = 0.4
COLOR = (10, 120, 10)

ANIMATION_DELAY = 0.1

ANIMATION_STAY = [('images/lll.png', ANIMATION_DELAY)]

ANIMATION_UP = ['images/lll2.png']

class Player(Sprite):
    def __init__(self, x, y):
        Sprite.__init__(self)
        self.image = Surface((60, 60))
        self.xvel = 0
        self.yvel = 0
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.onGround = False

        def make_boltAnim(anim_list, delay):
            boltAnim = []
            for anim in anim_list:
                boltAnim.append((anim, delay))
            Anim = pyganim.PygAnimation(boltAnim)
            return Anim

    def update(self, left, right, up, platforms):
    
        if left:
            self.xvel = -MOVE_SPEED
        if right:
            self.xvel = MOVE_SPEED
        if not(left or right):
            self.xvel = 0
            if not up:
                self.image.fill(COLOR)
                self.image = load('images/lll.png')

        if up:
            if self.onGround:
                self.yvel = -JUMP_POWER
            self.image = load('images/lll2.png')
       
        if not self.onGround:
            self.yvel += GRAVITY

        self.onGround = False
        self.rect.x += self.xvel
        self.collide(self.xvel, 0, platforms)
        self.rect.y += self.yvel
        self.collide(0, self.yvel, platforms)

    def collide(self, xvel, yvel, platforms):
        for pl in platforms:
            if collide_rect(self, pl):
                if xvel > 0:
                    self.rect.right = pl.rect.left
                if xvel < 0:
                    self.rect.left = pl.rect.right
                if yvel > 0:
                    self.rect.bottom = pl.rect.top
                    self.onGround = True
                    self.yvel = 0
                if yvel < 0:
                    self.rect.top = pl.rect.bottom
                    self.yvel = 0
